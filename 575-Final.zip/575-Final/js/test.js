//First line of main.js...wrap everything in a self-executing anonymous function to move to local scope
(function(){

//pseudo-global variables
        //variables for data join

var attrArray =[
    "att_2007", "ref_2007", "att_2008", "ref_2008",  "att_2009", "ref_2009", "att_2010", "ref_2010", "att_2011", "ref_2011", "att_2012","ref_2012", "att_2013", "ref_2013", "att_2014", "ref_2014", "att_2015", "ref_2015", "att_2016", "ref_2016"
    ];
    //console.log(attrArray)

//var attributes = [];
//    var properties = sahel.features[0].properties;
//    for( var attributes in properties) {
//        if(attributes.indexOf("ref_") > -1){
//            attributes.push(attribute);
//        };
//    };

   // console.log(attributes);
var expressed = attrArray[0]; //initial attribute
    
var chartdata
//console.log(expressed)
//set dimensions based on client window size
var w = $("container").width() * 0.6 ;
var h = window.innerHeight*0.85;

//dimension global variables
 var chartW = window.innerWidth * 0.425,
        chartH = 473,
        leftPadding = 25,
        rightPadding = 2,
        topBottomPadding = 5,
        chartInnerW = chartW - leftPadding - rightPadding,
        chartInnerH = chartH - topBottomPadding * 2,
        translate = "translate(" + leftPadding + "," + topBottomPadding + ")";



       var yScale = d3.scaleLog()
        .range([0, chartH])
        .domain([0, 1436667]);
    
    //max refugee 1436667

window.onload = setMap();

    
    function processData(data){
    //empty array to hold attributes
    var attributes = [];

    //properties of the first feature in the dataset
    var properties = csvData.features[0].properties;

    //push each attribute name into attributes array
    for (var attribute in properties){
        //only take attributes with population values
        if (attribute.indexOf("ref_") > -1){
            attributes.push(attribute);
        };
    };

    //check result
    console.log(attributes);

    return attributes;
};
//set up choropleth map
function setMap(){
    
        //map frame dimensions
        var width = window.innerWidth * 0.5,
            height = 800;

        //create new svg container for the map
        var map = d3.select("body")
            .append("svg")
            .attr("class", "map")
            .attr("width", width)
            .attr("height", height);

        //create Albers equal area conic projection centered on Sahel
        var projection = d3.geoAzimuthalEqualArea()
            .center([15, 10])
            .rotate([-2, 0, 0])
            .scale(1200)
            .translate([width / 2, height / 2]);

        var path = d3.geoPath()
            .projection(projection); 
    
    
    //use queue to parallelize asynchronous data loading
    d3.queue()
//        .defer(d3.csv, "data/Refugee.csv") //load attributes from csv
        .defer(d3.csv, "data/Ref_Att.csv") //load attributes from csv
        .defer(d3.json, "data/Africa.topojson") //load background spatial data
        .defer(d3.json, "data/Sahel.topojson") //load choropleth spatial data
        .await(callback);
    
function callback(error, csvData, africa, sahel){   
            //place graticule on the map
            setGraticule(map, path);      
        //translate europe TopoJSON
        var africa = topojson.feature(africa, africa.objects.Africa),
            sahel = topojson.feature(sahel, sahel.objects.Sahel).features;
        var attributes = [];
            var properties = csvData[0].properties;
            for( var attributes in properties) {
                if(attributes.indexOf("ref_") > -1){
                attributes.push(attribute);
                };
                console.log(attributes);
            };
          console.log(sahel)
        //add Africa countries to map
        var countries = map.append("path")
            .datum(africa)
            .attr("class", "countries")
            .attr("d", path);
         var colorScale = makeColorScale(csvData);
         
        sahel = joinData(sahel, csvData);
        //create the color scale  
        setEnumerationUnits(sahel, map, path, colorScale);
        //add coordinated visualization to the map
        setChart(csvData, colorScale);
        createDropdown(csvData);       
//        createRefugeeArray(csvData);
      };
};
//function createRefugeeArray(csvData){
//        var attributes = [];
//        var properties = csvData.features[0].properties;
//            for( var attributes in properties) {
//                if(attributes.indexOf("ref_") > -1){
//                attributes.push(attribute);
//                };
//                console.log(attributes);
//            }; 
//};
    //function to test for data value and return color
function choropleth(props, colorScale){
        //make sure attribute value is a number
        var val = parseFloat(props[expressed]);
        //if attribute value exists, assign a color; otherwise assign gray
            if (typeof val == 'number' && !isNaN(val)){
                return colorScale(val);
            } else {
                return "#CCC";
            };
};

//function to create coordinated scatter plot
function setChart(csvData, colorScale){
   var chartW = window.innerWidth * 0.425,
        chartH = 1000;

//create a second svg element to hold the scatter plot
    var container = d3.select("body")
        .append("svg")
        .attr("width", chartW)
        .attr("height", chartH)
        .attr("class", "container")
        .style("fill", "#FFFFFF"); //only put a semicolon at the end of the block!
        

       //create x scale
	var xScale = d3.scaleLinear() //scale generator
		.range([0,chartInnerW])
		.domain([0,2808]) //max is from US
		;
      var circles = container.selectAll(".circles") //but wait--there are no circles yet!
        .data(csvData) //here we feed in an array
        .enter() //one of the great mysteries of the universe
        .append("circle") //add a circle for each datum
        .attr("class", function(d){
            return "circles " + d.NAME_ENGLI;
       })
       .attr("r", 20)
        .attr("cx", function(d, i){
            return xScale(d.att_2015);
        })
        .attr("cy", function(d){
            return chartH - (parseFloat(d[expressed]) + 200);
        })
       .style("fill", function(d){
            return choropleth(d, colorScale);
        })
        .attr("class", function(d){
            return "circles " + d.NAME_ENGLI;
        })
        .on("mouseover", highlight)
         //Example 2.2 line 30...bars event listeners
        
        .on("mouseout", dehighlight);
//below Example 2.2 line 31...add style descriptor to each rect
    var desc = circles.append("desc")
        .text('{"stroke": "none", "stroke-width": "0px"}');
//below Example 2.8...create a text element for the chart title
    var chartTitle = container.append("text")
        .attr("x", 20)
        .attr("y", 40)
        .attr("class", "chartTitle")
        .text("Violence and Refugees in " + expressed[3] + " by country");
//create vertical axis generator
    var yAxis = d3.axisLeft()
        .scale(yScale)
//place axis
//    var axis = container.append("g")
//        .attr("class", "axis")
//        .attr("transform", translate)
//        .call(yAxis);


//update circle styles
       // updateChart(circles, csvData.length, colorScale);
};

//function to reset the element style on mouseout
function dehighlight(props){
    var selected = d3.selectAll("." + props.NAME_ENGLI)
        .style("stroke", function(){
            return getStyle(this, "stroke")
        })
        .style("stroke-width", function(){
            return getStyle(this, "stroke-width")
        });

    function getStyle(element, styleName){
        var styleText = d3.select(element)
            .select("desc")
            .text();

        var styleObject = JSON.parse(styleText);
        return styleObject[styleName];
    };
};
    
    //function to create a dropdown menu for attribute selection
function createDropdown(csvData){
    //add select element
    var dropdown = d3.select("body")
        .append("select")
        .attr("class", "dropdown")
        .on("change", function(){
            changeAttribute(this.value, csvData)
        });

    //add initial option
    var titleOption = dropdown.append("option")
        .attr("class", "titleOption")
        .attr("disabled", "true")
        .text("Select Attribute");

    //add attribute name options
    var attrOptions = dropdown.selectAll("attrOptions")
        .data(attrArray)
        .enter()
        .append("option")
        .attr("value", function(d){ return d })
        .text(function(d){ return d });
};
    //dropdown change listener handler
function changeAttribute(attribute, csvData){
    //change the expressed attribute
    expressed = attribute;

    //recreate the color scale
    var colorScale = makeColorScale(csvData);

    //recolor enumeration units
    var regions = d3.selectAll(".regions")
        .style("fill", function(d){
            return choropleth(d.properties, colorScale)
        });
    var circles = container.selectAll(".circles") //but wait--there are no circles yet!
        .data(csvData) //here we feed in an array
        .enter() //one of the great mysteries of the universe
        .append("circle") //add a circle for each datum
        .attr("class", function(d){
            return "circles " + d.NAME_ENGLI;
       })
       .attr("r", function(d, i){ //circle radius
            console.log("d:", d, "i:", i); //let's take a look at d and i
           var val = parseFloat(d.this/10)
           //var area = val
            return Math.sqrt(val/Math.PI);
        })
        .attr("cx", function(d, i){
            return i * (chartW / csvData.length);
        })
        .attr("cy", function(d){
            return chartH - yScale(parseFloat(d[expressed]));
        })
       .style("fill", function(d){
            return choropleth(d, colorScale);
        });
            updateChart(circles, csvData.length, colorScale);
};
//    //function to position, size, and color circles in chart
function updateChart(circles, n, colorScale){
    //position circles
    circles.attr("r", function(d, i){ //circle radius
            console.log("d:", d, "i:", i); //let's take a look at d and i
           var val = parseFloat(d.ref_2010/10)
           //var area = val
            return Math.sqrt(val/Math.PI);
        })
    
        .attr("cy", function(d){
            return chartH - yScale(parseFloat(d[expressed]));
        })
       .style("fill", function(d){
            return choropleth(d, colorScale);
        });
};
//function to create color scale generator
function makeColorScale(data){
    var colorClasses = [
        "#E4F1F6",
        "#67AFCB",
        "#347B98",
        "#265A6E",
        "#092834"
    ];

    
    //create color scale generator
    var colorScale = d3.scaleThreshold()
        .range(colorClasses);

    //build array of all values of the expressed attribute
    var domainArray = [];
    for (var i=0; i<data.length; i++){
        var val = parseFloat(data[i][expressed]);
        domainArray.push(val);
    };

    //cluster data using ckmeans clustering algorithm to create natural breaks
    var clusters = ss.ckmeans(domainArray, 5);
    //reset domain array to cluster minimums
    domainArray = clusters.map(function(d){
        return d3.min(d);
    });
    //remove first value from domain array to create class breakpoints
    domainArray.shift();

    //assign array of last 4 cluster minimums as domain
    colorScale.domain(domainArray);

    return colorScale;
};
          
    function setGraticule(map, path){
    //...GRATICULE BLOCKS FROM PREVIOUS MODULE
            //Example 2.5 line 3...create graticule generator
        var graticule = d3.geoGraticule()
            .step([5, 5]); //place graticule lines every 5 degrees of longitude and latitude
          
            //create graticule background
        var gratBackground = map.append("path")
            .datum(graticule.outline()) //bind graticule background
            .attr("class", "gratBackground") //assign class for styling
            .attr("d", path) //project graticule


        //create graticule lines
        var gratLines = map.selectAll(".gratLines") //select graticule elements that will be created
            .data(graticule.lines()) //bind graticule lines to each element to be created
            .enter() //create an element for each datum
            .append("path") //append each element to the svg as a path element
            .attr("class", "gratLines") //assign class for styling
            .attr("d", path); //project graticule lines
};
          
    function joinData(sahel, csvData){
    //...DATA JOIN LOOPS FROM EXAMPLE 1.1
           //loop through csv to assign each set of csv attribute values to geojson region
    for (var i=0; i<csvData.length; i++){
        var csvRegion = csvData[i]; //the current region
        var csvKey = csvRegion.NAME_ENGLI; //the CSV primary key

        //loop through geojson regions to find correct region
        for (var a=0; a<sahel.length; a++){

            var geojsonProps = sahel[a].properties; //the current region geojson properties
            var geojsonKey = geojsonProps.NAME_ENGLI; //the geojson primary key

            //where primary keys match, transfer csv data to geojson properties object
            if (geojsonKey == csvKey){

                //assign all attributes and values
                attrArray.forEach(function(attr){
                    var val = parseFloat(csvRegion[attr]); //get csv attribute value
                    geojsonProps[attr] = val; //assign attribute and value to geojson properties
                    
                });
            };
        };
    };
    return sahel;
};
    
    function setEnumerationUnits(sahel, map, path, colorScale){
    //...REGIONS BLOCK FROM PREVIOUS MODULE
    //add Sahelian countries to map
        var regions = map.selectAll(".regions")
            .data(sahel)
            .enter()
            .append("path")
            .attr("class", function(d){
                return "regions " + d.properties.NAME_ENGLI;
            })
            .attr("d", path)
            .style("fill", function(d){
                return colorScale(d.properties[expressed]);
            })
            .on("mouseover", function(d){
                highlight(d.properties);
            })
          .on("mouseout", function(d){
            dehighlight(d.properties);
        });

          //below Example 2.2 line 16...add style descriptor to each path
    var desc = regions.append("desc")
        .text('{"stroke": "#000", "stroke-width": "0.5px"}');

};    
     //function to highlight enumeration units and bars
function highlight(props){
    //change stroke
    var selected = d3.selectAll("." + props.NAME_ENGLI)
        .style("stroke", "blue")
        .style("stroke-width", "2");
};
    

})();