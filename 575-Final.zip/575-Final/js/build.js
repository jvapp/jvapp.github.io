 var data = (d3.json, "data/Sahel.topojson");

console.log(data)