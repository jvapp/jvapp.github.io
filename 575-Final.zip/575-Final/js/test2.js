//Example 1.3 line 4...set up choropleth map
function setMap(){
    //use d3.queue to parallelize asynchronous data loading
    d3.queue()
        .defer(d3.csv, "data/Ref_Att.csv") //load attributes from csv
        .defer(d3.json, "data/Sahel_data.topojson") //load background spatial data
        .defer(d3.json, "data/Africa.topojson") //load choropleth spatial data
        .await(callback);
    

    function callback(error, csvData, sahel, africa){
        
           var sahel = topojson.feature(sahel, sahel.objects.Sahel_data),
                africa = topojson.feature(africa, africa.objects.Africa).features;

        //examine the results
        console.log(sahel);
        console.log(csvData);
        console.log(africa);
        console.log(error);
       
    };
};